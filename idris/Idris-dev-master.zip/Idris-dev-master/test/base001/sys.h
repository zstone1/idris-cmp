#ifndef SYS_H
#define SYS_H

int WIFEXITED_(int status);
int WEXITSTATUS_(int status);

#endif
